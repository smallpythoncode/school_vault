/**
 * JokeServer.java
 *
 * CSCI 364, Spring 2025, HW1
 *
 * Author: Kenneth Jahnke
 */
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * A server that sends knock-knock jokes to terminal instance of JokeClient.
 *
 * Note: Server is designed to shut down only from using `Ctrl + C` within
 * the terminal.
 */
public class JokeServer {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// check command line args
		if (args.length != 3) {
			System.err.println("Usage: java JokeServer <port number> <joke text file> <seed value>");
			System.exit(1);
		}

		// a simpler implementation than java.io.FileReader(String) to check that the file merely exists
		File jokeFile = new File(args[1]);
		if (!jokeFile.exists()) {
			System.err.println("Joke text file not found: " + args[1]);
			System.exit(1);
		}

		// parse input seed string to long
		long seedNumber;
		Random rnd = null;
		try {
			seedNumber = Long.parseLong(args[2]);
			rnd = new Random();
			rnd.setSeed(seedNumber);
		} catch (NumberFormatException nfeLong) {
			System.err.println("Invalid seed number: " + args[2]);
			System.exit(1);
		}

		List<List<String>> jokeList = new ArrayList<>();
		int jokeListLength = 0;
		try (BufferedReader reader = new BufferedReader(new FileReader(jokeFile))) {
			String line;
			while ((line = reader.readLine()) != null) {
				String[] fullJoke = line.split("#");
				fullJoke[0] = fullJoke[0].trim();
				fullJoke[1] = fullJoke[1].trim();
				jokeList.add(Arrays.asList(fullJoke));
				jokeListLength += 1;
			}
		} catch (IOException e) {
			System.err.println("An error occurred while reading the file: " + e.getMessage());
			System.exit(1);
		}

		int portNumber = -1;
		try {
			// convert command line argument to int
			portNumber = Integer.parseInt(args[0]);

			ServerSocket serverSocket = new ServerSocket(portNumber);
			System.out.println("The server is listening at: " +
					serverSocket.getInetAddress() + " on port " +
					serverSocket.getLocalPort());
			while (true) {
				List<String> thisJoke = jokeList.get(rnd.nextInt(0, jokeListLength));  // error here
				String knock = "Knock knock.";
				String whothere = "Who is there?";
				String setup = thisJoke.get(0);
				String setupResponse = setup + " who?";
				String punchline = thisJoke.get(1);

				Socket clientSocket = serverSocket.accept();

				PrintWriter out = new PrintWriter(
						clientSocket.getOutputStream(), true, StandardCharsets.UTF_8);
				BufferedReader in = new BufferedReader(
						new InputStreamReader(clientSocket.getInputStream(), StandardCharsets.UTF_8));

				out.println(knock);
				String inputLine = in.readLine();
				if (!inputLine.equals(whothere)) {
					out.println("Invalid response: Try '" + whothere + "'");
					in.close();
					out.close();
					clientSocket.close();
					continue;
				}
				out.println(setup);
				inputLine = in.readLine();
				if (!inputLine.equals(setupResponse)) {
					out.println("Invalid response: Try '" + setup + " who?'");
					in.close();
					out.close();
					clientSocket.close();
					continue;
				}
				out.println(punchline);
				out.println("Bye.");

				in.close();  // can this be removed?
				out.close();  // can this be removed?
				clientSocket.close();
			}
		} catch (NumberFormatException nfe) {
			System.err.println("Invalid port number: " + args[0]);
			System.exit(1);
		} catch (IOException ioe) {
			System.err.println(ioe.getMessage());
			System.exit(1);
		}
	}
}
