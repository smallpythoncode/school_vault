/**
 * JokeClient.java
 *
 * CSCI 364, Spring 2025, HW1
 *
 * Author: Kenneth Jahnke
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

/**
 * A client that receives knock-knock jokes from a terminal instance of JokeServer.
 *
 * The client receives input from the server and is expected to follow standard
 * knock-knock joke protocol (or what is described in the assignment instructions).
 * If input is incorrect, the user will be given information on who to correct.
 * The user will then have to re-run the client instance to eventually receive the
 * punchline.
 *
 * Note: Inputs are case-sensitive.
 */
public class JokeClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		if (args.length != 2) {
			System.err.println("Usage: java SSClient <hostname> <port number>");
			System.exit(1);
		}

		String hostName = args[0];
		int portNumber = -1;
		try {
			// convert command line argument to int
			portNumber = Integer.parseInt(args[1]);

			Socket socket = new Socket(hostName, portNumber);

			// set up i/o between client and server
			PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
			BufferedReader in = new BufferedReader(
					new InputStreamReader(socket.getInputStream()));

			// knock-knock
			String inMsg = in.readLine();
			System.out.println(inMsg);

			// who is there?
			Scanner stdIn = new Scanner(System.in);
			String outMsg = stdIn.nextLine();
			out.println(outMsg);

			// setup
			inMsg = in.readLine();
			System.out.println(inMsg);
			String[] invalidCheck = inMsg.split(" ");
			if (invalidCheck[0].equals("Invalid") &&
					invalidCheck[1].equals("response:")) {
				System.exit(1);
			}

			// ... who?
			outMsg = stdIn.nextLine();
			out.println(outMsg);

			// punchline
			inMsg = in.readLine();
			System.out.println(inMsg);
			if (invalidCheck[0].equals("Invalid") &&
					invalidCheck[1].equals("response:")) {
				System.exit(1);
			}
			// bye
			inMsg = in.readLine();
			System.out.println(inMsg);

			stdIn.close();
			in.close();
			out.close();
		} catch (NumberFormatException nfe) {
			System.err.println("Invalid port number");
			System.exit(1);
		} catch (IOException ioe) {
			System.err.println(ioe.getMessage());
			System.exit(1);
		}
	}

}
