/**
 * hw2.Main.java
 * HW2
 * CSCI 364, Spring 2025
 *
 * @author jahnke
 */

package hw2;

/**
 * A bank account is created. A series of deposit and withdrawal threads are created. Along these threads are sent
 * deposit and withdrawal transactions. The transactions cannot put the account balance below $0 (zero) or twice the
 * accounts initial balance. The threads continue until a specified amount of milliseconds, at which time all threads
 * are interrupted. Upon final interrupt, relevant information about the many threads transactions and functioning is
 * printed, along with the final balance of the account.
 * `ant` and accompanying build.xml intended for compiling.
 * Usage (from terminal):
 * "java -cp build hw2.Main [num_deposit_threads] [num_withdrawal_threads] [initial_balance] [sleep_time_milliseconds]"
 *
 */
public class Main {
    public static void main(String[] args) {

        if (args.length != 4) {
            System.err.println("Usage: java -cp build hw2.Main <num_deposit_threads> " +
                    "<num_withdrawal_threads> <initial_balance> <sleep_time_milliseconds>");
            System.exit(1);
        }

        int numDepositThreads, numWithdrawalThreads, initialBalance, sleepMilliseconds;

        // validate command line arguments (all integers)
        try {
            numDepositThreads = Integer.parseInt(args[0]);
            numWithdrawalThreads = Integer.parseInt(args[1]);
            initialBalance = Integer.parseInt(args[2]);
            sleepMilliseconds = Integer.parseInt(args[3]);

            if (numDepositThreads < 1 || numWithdrawalThreads < 1) {
                throw new IllegalArgumentException("Invalid arguments: The number of deposit and withdrawal thread must each be at least one (>= 1).");
            }
            if (initialBalance <= 0) {
                throw new IllegalArgumentException("Invalid arguments: The initial balance must be a positive integer (> 0).");
            }
        } catch (Exception e) {
            System.err.println("Invalid input: All command line arguments should represented as integers.");
            return;
        }

        /// ///////////////////////////////////////////////

        Account account = new Account(initialBalance);
        Thread[] depositThreads = new Thread[numDepositThreads];
        Thread[] withdrawalThreads = new Thread[numWithdrawalThreads];

        for (int i = 0; i < numDepositThreads; i++) {
            depositThreads[i] = new Thread(new Deposit(account), "DepositThread-" + (i + 1));
            depositThreads[i].start();
        }

        for (int i = 0; i < numWithdrawalThreads; i++) {
            withdrawalThreads[i] = new Thread(new Withdrawal(account), "WithdrawalThread-" + (i + 1));
            withdrawalThreads[i].start();
        }

        try {
            Thread.sleep(sleepMilliseconds);
        } catch (InterruptedException ignored) {
        }

        for (Thread t : depositThreads) {
            t.interrupt();
        }

        for (Thread t : withdrawalThreads) {
            t.interrupt();
        }

        for (Thread t : depositThreads) {
            try {
                t.join();
            } catch (InterruptedException ignored) {
            }
        }

        for (Thread t : withdrawalThreads) {
            try {
                t.join();
            } catch (InterruptedException ignored) {
            }
        }

        System.out.println("\nFinal account balance: " + account.getBalance());

    }

}
