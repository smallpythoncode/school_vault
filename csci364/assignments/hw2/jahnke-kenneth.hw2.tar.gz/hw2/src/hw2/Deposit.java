/**
 * hw2.Deposit.java
 * HW2
 * CSCI 364, Spring 2025
 *
 * @author jahnke
 */

package hw2;

import java.util.concurrent.ThreadLocalRandom;

public class Deposit implements Runnable{
    /** The target account in which to deposit funds */
    private final Account account;
    /** The total amount in dollars this thread has deposited */
    private int totalDeposited = 0;
    /** The number of deposit transactions */
    private int depositCount = 0;
    /** The number times this thread had to wait */
    private int waitCount = 0;

    /**
     * hw2.Deposit constructor
     * @param account The account in which an instance deposits
     */
    public Deposit(Account account) {
        this.account = account;
    }

    /**
     * Tracking the number of times a deposit thread had to wait
     */
    public void incrementDepositWait() {
        waitCount++;
    }

    /**
     * The running of a thread that continually attempts to deposit between $1 and $100 into target account until interrupted.
     * Will print relevant information upon interrupt.
     */
    @Override
    public void run() {
        try {
            while (!Thread.currentThread().isInterrupted()) {
                int amount = ThreadLocalRandom.current().nextInt(1, 100);
                try {
                    account.deposit(amount, this);
                    totalDeposited += amount;
                    depositCount++;
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        } catch (Exception ignored) {
        } finally {
            System.out.printf("%-20s deposited ($): %12d,  deposit count:    %10d,  waits: %8d%n",
                    Thread.currentThread().getName(), totalDeposited, depositCount, waitCount);
        }
    }
}
