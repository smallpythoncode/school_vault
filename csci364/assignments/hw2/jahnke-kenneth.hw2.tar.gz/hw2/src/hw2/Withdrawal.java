/**
 * hw2.Withdrawal.java
 * HW2
 * CSCI 364, Spring 2025
 *
 * @author jahnke
 */

package hw2;

import java.util.concurrent.ThreadLocalRandom;

public class Withdrawal implements Runnable {
    /** The target account in which to withdraw funds */
    private final Account account;
    /** The total amount in dollars this thread has been withdrawn */
    private int totalWithdrawn = 0;
    /** The number of withdrawal transactions */
    private int withdrawalCount = 0;
    /** The number times this thread had to wait */
    private int waitCount = 0;

    /**
     * hw2.Withdrawal constructor
     * @param account The account in which an instance deposits
     */
    public Withdrawal(Account account) {
        this.account = account;
    }

    /**
     * Tracking the number of times a withdrawal thread had to wait
     */
    public void incrementWithdrawalWait() {
        waitCount++;
    }

    /**
     * The running of a thread that continually attempts to withdraw between $1 and $100 into target account until interrupted.
     * Will print relevant information upon interrupt.
     */
    @Override
    public void run() {
        try {
            while (!Thread.currentThread().isInterrupted()) {
                int amount = ThreadLocalRandom.current().nextInt(1, 100);
                try {
                    account.withdraw(amount, this);
                    totalWithdrawn += amount;
                    withdrawalCount++;
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        } catch (Exception ignored) {
        } finally {
            System.out.printf("%-20s withdrawn ($): %12d,  withdrawal count: %10d,  waits: %8d%n",
                    Thread.currentThread().getName(), totalWithdrawn, withdrawalCount, waitCount);
        }
    }
}
