/**
 * hw2.Account.java
 * HW2
 * CSCI 364, Spring 2025
 *
 * @author jahnke
 */

package hw2;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Account {
    /** The current balance of the account */
    private int balance;
    /** The initial balance of the account (specified as command line argument) */
    private final int initialBalance;
    /** The maximum allowable balance of the account (twice the initial balance) */
    private final int maxBalance;

    /**
     * Thread-safe synchronization
     * https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/concurrent/locks/Lock.html
     * https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/concurrent/locks/ReentrantLock.html
     */
    private final Lock lock = new ReentrantLock();

    /**
     * Management of thread waiting
     * https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/concurrent/locks/Condition.html
     */
    private final Condition condition = lock.newCondition();

    /**
     * Constructor initializes account
     * @param initialBalance The initial balance of the account
     */
    public Account(int initialBalance) {
        this.balance = initialBalance;
        this.initialBalance = initialBalance;
        this.maxBalance = 2 * initialBalance;
    }

    /**
     *
     * @param amount The amount to deposit
     * @param runnable The instance of the hw2.Withdrawal thread
     * @throws InterruptedException `hw2.Main` interrupts thread after sleepMilliseconds has passed
     */
    public void deposit(int amount, Deposit runnable) throws InterruptedException {
        lock.lock();
        try {
            while (balance + amount > maxBalance) {
                runnable.incrementDepositWait();
                condition.await();  // exceed maximum balance
            }
            balance += amount;
            condition.signalAll();  // waiting threads notified of change in balance
        } finally {
            lock.unlock();
        }
    }

    /**
     * Withdrawing funds from the account via a hw2.Withdrawal thread (Runnable)
     * @param amount The amount to withdraw
     * @param runnable The instance of the hw2.Withdrawal thread
     * @throws InterruptedException `hw2.Main` interrupts thread after sleepMilliseconds has passed
     */
    public void withdraw(int amount, Withdrawal runnable) throws InterruptedException {
        lock.lock();
        try {
            while (balance - amount < 0) {
                runnable.incrementWithdrawalWait();
                condition.await();  // insufficient funds
            }
            balance -= amount;
            condition.signalAll();  // waiting threads notified of change in balance
        } finally {
            lock.unlock();
        }
    }

    /**
     * Retrieve account balance (getter)
     * @return The account balance (integer)
     */
    public int getBalance() {
        return balance;
    }
}
