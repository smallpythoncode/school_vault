/**
 * ResourcePool.java
 */
package mutex;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Semaphore;

/**
 * Demonstrates the combination of a Semaphore with a collection of resources.
 *
 * @author david
 * @author jahnke
 */
public class ResourcePool {
    /** the number of resource Objects */
    private int poolSize;
    /** a counting semaphore */
    private Semaphore control;
    /** the resources managed by this pool */
    private List<Object> resources;
    /** a list showing whether resources are available */
    private List<Boolean> avail;

    /**
     * Creates a pool of resource objects.
     *
     * @param size the number of resources this pool manages
     */
    public ResourcePool(int size) {
        poolSize = size;
        control = new Semaphore(poolSize, true);
        resources = new ArrayList<>();
        avail = new ArrayList<>();

        for (int i = 0; i < poolSize; i++) {
            Object resource = new Object();
            resources.add(resource);
            avail.add(Boolean.TRUE);
        }
    }

    /**
     * Attempts to borrow a resource.
     *
     * @return a resource if one is available. Otherwise, return null.
     * @throws InterruptedException if a thread is interrupted waiting for a resource
     */
    public Object getResource() throws InterruptedException {
        control.acquire();
        return getNextAvailable();
    }

    /**
     * Returns a borrowed resource to this pool.
     *
     * @param resource the resource to be returned
     */
    public void putResource(Object resource) {
        int index = getIndex(resource);
        if (index >= 0) {
            synchronized (this) {
                if (!avail.get(index)) {
                    avail.set(index, true);
                    control.release();
                }
            }
        }
    }

    /**
     * Gets the number of resources available.
     *
     * @return the number of resources available.
     */
    public int getAvailable() {
        return control.availablePermits();
    }

    /**
     * Retrieves an available resource. Searches this pool for an available
     * resource. If an available resource is found, the resource is marked as
     * used and returned.
     *
     * @return the first available resource. Returns null if no resource
     * is available.
     */
    private Object getNextAvailable() {
        synchronized (this) {
            for (int i = 0; i < poolSize; i++) {
                if (avail.get(i)) {
                    avail.set(i, false);
                    return resources.get(i);
                }
            }
        }
        return null;
    }

    /**
     * Identifies the list index of a potential resource.
     *
     * @param resource the resource
     *
     * @return the index of resource in the list of resources. Returns a
     * negative value if the resource is not in the list of resources.
     */
    private int getIndex(Object resource) {
        return resources.indexOf(resource);
    }
}
