/**
 * SemaphoreDemo.java
 */
package mutex;

/**
 * Demonstrates a class that uses a Semaphore.
 *
 * @author david
 * @see mutex.ResourcePool
 */
public class SemaphoreDemo {
    /**
     * A default constructor. Included here so JavaDoc does not complain.
     */
    public SemaphoreDemo() {
        // empty
    }

	/**
     * Program entry point.
     *
	 * @param args no command line arguments
	 */
	public static void main(String[] args) {
		ResourcePool pool = new ResourcePool(5);

		System.out.println("Testing semaphore count");
		System.out.println("Available permits: " + pool.getAvailable());

        /*
         * The ResourcePool was created with all of its objects already in it.
         * It is designed to keep track of specific instances of resources.
         * New objects cannot be added.
         */
        for (int i = 0; i < 3; i++) {
 		 	pool.putResource(new Object());
 		}
		System.out.println("Available permits: " + pool.getAvailable());

        try {
            System.out.println("\nBorrow two resources");
            Object objA = pool.getResource();
            Object objB = pool.getResource();
            System.out.println("Available permits: " + pool.getAvailable());

            System.out.println("\nPut one resource back");
            pool.putResource(objA);
            System.out.println("Available permits: " + pool.getAvailable());
            System.out.println("Can I put the same resource back?");
            pool.putResource(objA);

            System.out.println("\nPut the other resource back");
            pool.putResource(objB);
            System.out.println("Available permits: " + pool.getAvailable());
        } catch (InterruptedException ie) {
            ie.printStackTrace();
        }

        System.out.println("Done");
	}

}
