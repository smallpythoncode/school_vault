/**
 *
 */
package myrmi.api;

import java.io.Serializable;

public class Message implements Serializable {
    private String msg = "";

    public Message() {
        // do nothing
    }

    public Message(String m) {
        msg = m;
    }

    public String toString() {
        return msg;
    }
}

