/**
 *
 */
package myrmi.client;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import myrmi.api.Hello;
import myrmi.api.Message;

/**
 *
 * @author david
 */
public class Client {

	/**
	 * Launch the client process.
	 *
	 * @param args host (or ip address) of RMI registry
	 */
	public static void main(String[] args) {
		System.out.println("Starting myrmi.client.Client...");
		if (args.length != 1) {
			System.out.println("Usage: $ java Client <server host>");
			System.exit(1);
		}

		String host = args[0];

		try {
			Registry registry = LocateRegistry.getRegistry(host);
			Hello stub = (Hello)registry.lookup(Hello.REMOTE_NAME);

			String[] names = Naming.list(Hello.REMOTE_NAME);
			System.out.println("remote objects: ");
			for (String name : names) {
				System.out.println("\t" + name);
			}

			Message response = stub.sayHello("UND");
			System.out.println("response: " + response.toString());

			response = stub.sayHello("David");
			System.out.println("response: " + response.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
