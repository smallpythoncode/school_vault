/**
 *
 */
package myrmi.server;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

import myrmi.api.Hello;
import myrmi.api.Message;

/**
 * Implements the remote object and publishes it. This can be done
 * with two approaches.
 * <ul>
 * <li>Server can extend UnicastRemoteObject</li>
 * <li>Server.main can call UnicastRemoteObject.exportObject
 * </ul>
 *
 * @author david
 */
public class Server implements Hello {

	@Override
	public Message sayHello(String name) {
        System.out.println("about to say hello...");
		StringBuilder sb = new StringBuilder("Hello, ");
		if (name == null) {
			sb.append("world");
		} else {
			sb.append(name);
		}

		Message msg = new Message(sb.toString());
		return msg;
	}

	/**
     * Launch the server process, the RMI registry, and publish (aka bind)
     * the RMI remote object.
	 *
	 * @param args not used
	 */
	public static void main(String[] args) {
		System.out.println("Starting myrmi.server.Server...");

		try {
			Hello obj = new Server();
			Hello stub = (Hello)UnicastRemoteObject.exportObject(obj, 0);
            Registry registry = LocateRegistry.createRegistry(1099);
			registry.rebind(Hello.REMOTE_NAME, stub);

			System.out.println("Server ready");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
