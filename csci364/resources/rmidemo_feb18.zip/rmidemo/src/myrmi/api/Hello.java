/**
 *
 */
package myrmi.api;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * @author david
 *
 */
public interface Hello extends Remote {
    public static final String REMOTE_NAME = "Hello";
	Message sayHello(String name) throws RemoteException;
}
