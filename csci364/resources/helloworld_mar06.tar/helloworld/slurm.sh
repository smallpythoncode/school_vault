#!/usr/bin/env bash

#SBATCH --job-name=hi
#SBATCH --partition=talon-short
#SBATCH --time=00:01:00
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --output=%x.%j.txt
module list

echo "Job started at $(date)"
hostname
echo "--"
./hello "<your name>"
echo "Job ended at $(date)"
